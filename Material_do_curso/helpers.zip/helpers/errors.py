
class WaitForElementError(Exception):
    pass


class ExpectedElementError(Exception):
    pass

